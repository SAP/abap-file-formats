# ILMB File Format

File | Cardinality | Definition | Schema | Example
:--- | :--- | :--- | :--- | :---
`<name>.ilmb.json` | 1 | [`zif_aff_ilmb_v1.intf.abap`](./type/zif_aff_ilmb_v1.intf.abap) | [`ilmb-v1.json`](./ilmb-v1.json)
